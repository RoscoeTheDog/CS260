//
//  main.cpp
//  Lab5
//
//  Created by Jim Bailey on 5/12/17.
//  Licensed under a Creative Commons Attribution 4.0 International License.
//

#include <iostream>
#include <iomanip>

#include "Tree234.h"

using namespace std;

int main()
{
    cout << "Testing 234 Tree" << endl;
        // define the tree
    Tree234 the234Tree;
    
    the234Tree.insert(50);
    the234Tree.insert(40);
    the234Tree.insert(60);
    the234Tree.insert(30);
    the234Tree.insert(70);
    the234Tree.insert(80);
    the234Tree.insert(90);
    the234Tree.insert(10);
    the234Tree.insert(20);
    
        // testing find
    cout << "Looking for 50 " << (the234Tree.find(50)?"found":"not found") << endl;
    cout << "Looking for 40 " << (the234Tree.find(40)?"found":"not found") << endl;
    cout << "Looking for 55 " << (the234Tree.find(55)?"found":"not found") << endl;
    cout << "Looking for 30 " << (the234Tree.find(30)?"found":"not found") << endl;
    
        // display tree
    cout << the234Tree.display() << endl;
    
    return 0;
}
